/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package welcomepage;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
// import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class WelcomeSceneController implements Initializable {
    
    @FXML
    ProgressBar progressBar = new ProgressBar();
    @FXML
     Label labelProgress = new Label();
    
    public Task<ObservableList> task = new Task<ObservableList>(){
            @Override
            protected ObservableList call() throws Exception {
            for (int i = 0; i < 101; i++){
                updateProgress(i, 99);
                updateMessage(""+i);
                Thread.sleep(200);
             }
            return null;
            }
       };
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        progressBar.progressProperty().bind(task.progressProperty());
        task.messageProperty().addListener(new ChangeListener<String>() {
             @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue){
                   labelProgress.setText("Loading system in "+newValue+"%");
            }
    });    
        new Thread(task).start();
   }
}
